package com.example.upgrad;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/mainapp")
public class AppController {
	
	
	@GetMapping("/welcome")
	//@RequestMapping(value="/welcome", method =RequestMethod.GET)
	@ResponseBody
	public String sayWelcome() {
		
		return "welcome to spring boot";
	}

	

	@GetMapping("/login")
	
	public String login() {
		
		return "login";
	}
	@PostMapping("/login")
	public String loginValid(@RequestParam("uname")String name, @RequestParam("pass")String pass) {
		
		if(name.equals("admin") && pass.equals("manager")) {
			return " user is validated";
		}
		return " invalid user";
		
		
	}
	
	
	
	
}
