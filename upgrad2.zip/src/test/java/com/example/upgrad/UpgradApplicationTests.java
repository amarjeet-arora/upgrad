package com.example.upgrad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpgradApplicationTests {

	@Test
	void contextLoads() {
	}

}
