package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.LoginDao;
import com.dao.RegisterDAO;
import com.model.Login;
import com.service.LoginServiceImpl;
@RestController
public class App2Controller {

	@Autowired
	private LoginDao loginDao;
	
	
	@Autowired
	private RegisterDAO registerDAO;
	
	
	@PostMapping("/login")
	 
	public String loginValid(@RequestParam("uname")String name, @RequestParam("pass")String pass) {
		
		//Login login= new Login(name, pass);
		if (loginDao.login(name, pass)) {
			return "valid user";
		}
	 
		return " invalid user";
		
		
	}
	@PostMapping("/register")
	public String addUser(@RequestParam("uname")String name,@RequestParam("email")String email ,@RequestParam("pass")String pass) {
	
		if(registerDAO.addUser(name, email, pass)) {
			
			
			return " user added";
		}
		
		return null;
		
		
	}
	
	
	
	
	
	
	
	@GetMapping("/welcome")
	 
	 
	public String sayWelcome() {
		
		return "welcome to spring boot";
	}
	
	
}
