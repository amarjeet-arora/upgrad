package com.model;

public class Register {
	
private String name;
private String email;
private String password;
public Register(String name, String email, String password) {
	super();
	this.name = name;
	this.email = email;
	this.password = password;
}
public Register() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Register [name=" + name + ", email=" + email + ", password=" + password + "]";
}


}
