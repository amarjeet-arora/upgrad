package com.service;

import org.springframework.stereotype.Service;

import com.dao.LoginDao;



@Service
public class LoginServiceImpl implements LoginDao{

	@Override
	public boolean login(String uname, String pass) {
		// TODO Auto-generated method stub
		
		if(uname.equals("admin") && pass.equals("manager")) {
		return true;
	}
		
		return false;

}}
