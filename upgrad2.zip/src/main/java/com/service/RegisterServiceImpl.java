package com.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.dao.RegisterDAO;
import com.model.Register;

@Service
public class RegisterServiceImpl implements RegisterDAO{
	
	
	private ArrayList< Register> al= new ArrayList<Register>();

	@Override
	public boolean addUser(String name, String email, String password) {
		
al.add(new Register(name, email, password));

System.out.println(al);
		
		
		
		return true;
	}

}
