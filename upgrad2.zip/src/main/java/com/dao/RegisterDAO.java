package com.dao;

public interface RegisterDAO {
	
	public boolean addUser(String name,String email,String password);

}
