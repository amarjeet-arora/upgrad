package com.dao;
public interface LoginDao {
	
	
	public boolean login(String uname,String pass );

}
